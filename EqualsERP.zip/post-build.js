const FTP_USER = "vediancrmcom";
const FTP_PASSWORD = "wydlripgmjekq0ouasv#";
const FTP_HOST = "103.234.116.215";
const FTP_PORT = 21;
const FTP_PASSIVE_MODE = true;
const FTP_ROOT = "/accounts.vediancrm.com/wwwroot";
const LOCAL_ROOT = `${__dirname}/dist/ERP`;

const FtpDeploy = require("ftp-deploy");
const Progress = require("cli-progress");
const FileSystem = require('fs');

var bar = undefined;

function CreateProgressBar(data) {
  if (bar !== undefined)
    return;

  bar = new Progress.SingleBar({
    format: 'FTP Upload: [{bar}] {percentage}% | {value} of {total} files | ETA: {eta_formatted}',
    hideCursor: true
  }, Progress.Presets.shades_classic);

  bar.start(data.totalFilesCount, data.transferredFileCount);
}

function ShowProgress(data) {
  CreateProgressBar(data);

  bar.setTotal(data.totalFilesCount);
  bar.update(data.transferredFileCount);
}

function DeleteDirectory(path) {
  if (FileSystem.existsSync(path) && FileSystem.lstatSync(path).isDirectory()) {
    FileSystem.readdirSync(path).forEach(function (file, index) {
      let currentPath = `${path}/${file}`;
      if (FileSystem.lstatSync(currentPath).isDirectory())
        DeleteDirectory(currentPath);
      else
        FileSystem.unlinkSync(currentPath);
    });

    console.log(`Deleting directory ${path}...`);
    FileSystem.rmdirSync(path);
  }
};

var ftpDeploy = new FtpDeploy();
ftpDeploy.on("uploading", function (data) {
  ShowProgress(data);
});
ftpDeploy.on("uploaded", function (data) {
  ShowProgress(data);
});
ftpDeploy.on("log", function (data) {
  ShowProgress(data);
});
ftpDeploy.on("upload-error", function (data) {
  bar.stop();

  console.log('An error occured while publishing files to FTP.');
  console.log(data.err); // data will also include filename, relativePath, and other goodies
});

var config = {
  user: FTP_USER,
  password: FTP_PASSWORD,
  host: FTP_HOST,
  port: FTP_PORT,
  localRoot: LOCAL_ROOT,
  remoteRoot: FTP_ROOT,
  include: ["*", "**/*"], // this would upload everything except dot files
  exclude: ["dist/**/*.map", "node_modules/**", "node_modules/**/.*", ".git/**"], // e.g. exclude sourcemaps, and ALL files in node_modules (including dot files)
  deleteRemote: true, // delete ALL existing files at destination before uploading, if true
  forcePasv: FTP_PASSIVE_MODE, // Passive mode is forced (EPSV command is not sent)
  sftp: false // use sftp or ftp
};

ftpDeploy
  .deploy(config)
  .then(res => {
    bar.stop();
    console.log("\nUpload complete, now deleting build directory.");

    let buildDirectory = `${__dirname}/dist`;
    DeleteDirectory(buildDirectory);
  })
  .catch(err => console.log(err));
