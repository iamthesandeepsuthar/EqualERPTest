export const environment = {
  production: true,
  apiBase: 'http://test.vediancrm.com/api',
};
