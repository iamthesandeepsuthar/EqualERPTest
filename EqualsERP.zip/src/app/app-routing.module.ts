import { LoginComponent } from './login/login.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {  path: '',
    redirectTo:'login',
     pathMatch: 'full',
  }, 
  {
    path: 'erp',
    loadChildren: () => import('./erp/erp.module').then(m => m.ERPModule)
  },
  {
    path:'login',
    component: LoginComponent
  },
  {
    path:'Auto-Login/:userId',
    component: LoginComponent,
  },
  {
    path:'Auto-Login/:userId/:returnUrl',
    component: LoginComponent,
  }
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
