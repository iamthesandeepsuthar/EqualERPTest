import { ServiceResponse } from './../model/api-response.model';
import { Injectable } from '@angular/core';
import { HttpParams, HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Constants } from '../Constants';
import { Observable } from 'rxjs';
import { ApiResponse } from '../model/api-response.model';

@Injectable({
  providedIn: 'root'
})
export class BaseService {
  public readonly Constants = Constants;

  constructor(private readonly _httpClient: HttpClient) { }

  public get HttpClient(): HttpClient {
      return this._httpClient;
  }

  public Get<T>(url: string): Observable<ApiResponse<T>> {
    return this.HttpClient.get<ApiResponse<T>>(url);
}

public  Post<T>(url: string, data: any): Observable<ServiceResponse<any>> {
    const headers = { 'content-type': 'application/json' };
    return this.HttpClient.post<ServiceResponse<any>>(url, data, { headers: headers });
}

public  Delete<T>(url: string): Observable<ApiResponse<T>> {
    return this.HttpClient.delete<ApiResponse<T>>(url);
}
}
