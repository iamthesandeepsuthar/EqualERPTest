import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Bills, Party, PaymentMode, PaymentType } from '../model/Common/payment-mode.model';
import { PaymentReceiveModel } from '../model/PaymentReceipt';
import { BaseService } from './base.service';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  constructor( private readonly _baseService: BaseService) {  }
  GetPaymentMode() {
    let url = `${this._baseService.Constants.PaymentMode_Api}`;
    return this._baseService.Get<PaymentMode[]>(url);
  }
  GetPaymentType() {
    let url = `${this._baseService.Constants.PaymentType_Api}`;
    return this._baseService.Get<PaymentType[]>(url);
  }
  GetParty(id:number){
    let url = `${this._baseService.Constants.GetParty_Api}/${id}`;
    return this._baseService.Get<Party[]>(url);
  }
  GetBills(id: number, entryTye: number) {
    let url = `${this._baseService.Constants.GetBills_Api}/${id}/${entryTye}`;
    return this._baseService.Get<Bills[]>(url);
  }
  SavePaymentTransaction(model: PaymentReceiveModel) {
    let url = `${this._baseService.Constants.SaveReceiptTransaction_Api}`;
    return this._baseService.Post<boolean>(url, model);
  }
}
