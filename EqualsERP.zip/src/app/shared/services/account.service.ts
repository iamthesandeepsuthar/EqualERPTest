import { CustomerModel, UnderGroupModel, AccountModel, DDLAccountModel } from './../model/account-model.model';
import { Injectable } from '@angular/core';
import { BaseService } from './base.service';
import { IndexModel } from '../model/Common/api-request.model';

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  constructor( private readonly _baseService: BaseService) {  }
  GetCustomer() {
    let url = `${this._baseService.Constants.Customers_Api}`;
    return this._baseService.Get<CustomerModel[]>(url);
  }
  GetAccounts() {
    let url = `${this._baseService.Constants.DDLAccount_Api}`;
    return this._baseService.Get<DDLAccountModel[]>(url);
  }
  GetAllAccounts(model : IndexModel) {
    let url = `${this._baseService.Constants.GetAllAccounts_Api}`;
    return this._baseService.Post<AccountModel[]>(url,model);
  }
  GetAccountDetail(id:number) {
    let url = `${this._baseService.Constants.GetAccountDetail_Api}/${id}`;
    return this._baseService.Get<AccountModel>(url);
  }
  GetUnderGroup() {
    let url = `${this._baseService.Constants.UnderGroup_Api}`;
    return this._baseService.Get<UnderGroupModel[]>(url);
  }
  SaveAccount(model: AccountModel) {
    let url = `${this._baseService.Constants.AddAccount_Api}`;
    return this._baseService.Post<boolean>(url, model);
  }
  DeleteAccount(Id:number) {
   let url = `${this._baseService.Constants.DeleteAccount_Api}/${Id}`;
   return this._baseService.Delete<boolean>(url);
  }
}
