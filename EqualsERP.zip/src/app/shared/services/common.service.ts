import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AuthenticationService } from './auth.service';
import { BaseService } from './base.service';


@Injectable({
  providedIn: 'root'
})
export class CommonService {
  data: number[] = [];
  constructor(private readonly _baseService: BaseService, private readonly _auth: AuthenticationService) { }




  ScrollingTop() {
    let scrollToTop = window.setInterval(() => {
      let pos = window.pageYOffset;
      if (pos > 0) {
        window.scrollTo(0, pos - 20); // how far to scroll on each step
      } else {
        window.clearInterval(scrollToTop);
      }
    }, 16);
  }
  setStorage(key : string, value : string) {
    localStorage.setItem(key, value);
    return true;
  }

  getStorage(key:string) {

    let decValue = localStorage.getItem(key)
    return decValue ? decValue : undefined;
  }
  removeStorage(key:string) {
    localStorage.removeItem(key);
  }

   GetParameter(route: ActivatedRoute, key: string): any {
    const map = route.snapshot.paramMap;
    if (map.has(key))
        return map.get(key);

    return null;
  }

   GetQueryParameter(route: ActivatedRoute, key: string): any {
    let map = route.snapshot.queryParamMap;
    if (map.has(key))
        return map.get(key);
    return null;
}

  // encrypt(txt:string) {
  //   return CryptoJS.AES.encrypt(txt, environment.AESKey.trim()).toString();
  // }

  // decrypt(txt :string) {
  //   return CryptoJS.AES.decrypt(txt, environment.AESKey.trim()).toString(CryptoJS.enc.Utf8);
  // }



}

