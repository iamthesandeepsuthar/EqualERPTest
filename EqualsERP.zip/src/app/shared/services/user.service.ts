import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ApiResponse } from '../model/api-response.model';
import { BaseService } from './base.service';

@Injectable({
  providedIn: 'root'
})
export class UserService extends BaseService{

  constructor(http: HttpClient) { super(http); }
  AutoLogin(Id: number) {
    let url = `${this.Constants.AutoLoginUrl}/${Id}`;
    return this.Get<ApiResponse<string>>(url);
  }

}
