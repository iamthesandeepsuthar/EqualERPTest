import { JournalLedgerRequestModel, JournalLedgerModel, FinalJournalLedgerModel } from './../model/journal-ledger-model.model';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BaseService } from './base.service';
import { ServiceResponse } from '../model/api-response.model';

@Injectable({
  providedIn: 'root'
})
export class JournalLedgerService extends BaseService{

  constructor(http: HttpClient) { super(http); }
  GetJournalLedgerList(model: JournalLedgerRequestModel) {
    let url = `${this.Constants.GetAllJournalLedger_Api}`;
    return this.Post<ServiceResponse<FinalJournalLedgerModel>>(url, model);
  }
}
