import { CommonService } from './common.service';
import { Observable, Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Constants } from '../Constants';
import { ApiResponse } from '../model/api-response.model';

import { BaseService } from './base.service';

@Injectable({
  providedIn: 'root',
})
export class AuthenticationService extends BaseService {
  public IsAuthentication = new Subject<boolean>();
  constructor( http: HttpClient, private readonly _baseService: BaseService, private _router: Router ) {
    super(http);
    this.IsAuthenticate();
  }

  IsAccessibleUrl(requestedUrl: string): boolean {
    return true;
  }

  AutoLogin(id: string) {
    let url = `${this.Constants.AutoLoginUrl + id}`;
    return this.Get(url);
  }

  IsAuthenticate() {
    setTimeout(() => {
      let token = localStorage.getItem('authToken');
      let sessionTime = localStorage.getItem('sessionTime');
      let currentSessionTime = Number(new Date().getTime());
      if (token != null && Number(sessionTime) > currentSessionTime) {
        this.IsAuthentication.next(true);
      } else {

        this.LogOut();
      }
    }, 5);
  }

  LogOut() {
    this.IsAuthentication.next(false);
    localStorage.removeItem('authToken');
    localStorage.removeItem('sessionTime');
    setTimeout(() => {
      if (this._router.url !== 'Auto-Login') {
        this._router.navigate(['']);
      }
    }, 10);
  }
}
