import { PaymentType } from './../model/Common/payment-mode.model';
import { BaseService } from './base.service';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PaymentReceiveModel } from '../model/PaymentReceipt';
import { Bills, Party, PaymentMode, } from '../model/Common/payment-mode.model';
import { ServiceResponse } from '../model/api-response.model';

@Injectable({
  providedIn: 'root'
})
export class ReceiptService extends BaseService{

  constructor(http: HttpClient) { super(http); }
  GetPaymentMode() {
    let url = `${this.Constants.PaymentMode_Api}`;
    return this.Get<PaymentMode[]>(url);
  }
  GetPaymentType() {
    let url = `${this.Constants.PaymentType_Api}`;
    return this.Get<PaymentType[]>(url);
  }
  GetParty(id:number){
    let url = `${this.Constants.GetParty_Api}/${id}`;
    return this.Get<Party[]>(url);
  }
  GetBills(id: number, entryTye: number) {
    let url = `${this.Constants.GetBills_Api}/${id}/${entryTye}`;
    return this.Get<Bills[]>(url);
  }
  SaveReceiptTransaction(model: PaymentReceiveModel) {
    let url = `${this.Constants.SaveReceiptTransaction_Api}`;
    return this.Post<ServiceResponse<string>>(url, model);
  }
}
