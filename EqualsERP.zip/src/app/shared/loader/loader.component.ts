import { Component, AfterViewChecked, ChangeDetectorRef } from "@angular/core";
import { LoaderService } from "../services/loader.service";


@Component({
  selector: 'app-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.css']
})
export class LoaderComponent implements AfterViewChecked {

  loading: boolean = false;
  constructor(private loaderService: LoaderService, private cdRef: ChangeDetectorRef) {

  }

  ngAfterViewChecked(): void {
    this.loaderService.isLoading.subscribe((isLoading) => {
      this.loading = isLoading;
      this.cdRef.detectChanges();
    });
  }

}
