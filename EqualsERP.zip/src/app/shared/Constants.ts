import { environment } from "src/environments/environment";

export class Constants {
  //#region Setting URL
  public static API_BASE = environment.apiBase;
  public static AutoLoginUrl = `${Constants.API_BASE}/UserAccount/AutoLogin/`;
  public static Add_Account_URL = `/erp/account`;
  public static Account_Detail_URL =`/erp/view-account`;
  public static Account_List_URL=`/erp/accounts`;
  public static Account_Update_URL=`/erp/account`;
  //#endregion


   // API URL
   public static PaymentMode_Api =`${Constants.API_BASE}/ReceiptPayment/PaymentMode`;
   public static PaymentType_Api=`${Constants.API_BASE}/ReceiptPayment/PaymentType`;
   public static GetParty_Api = `${Constants.API_BASE}/ReceiptPayment/GetParty`;
   public static GetBills_Api=`${Constants.API_BASE}/ReceiptPayment/GetBills`;
   public static SaveReceiptTransaction_Api=`${Constants.API_BASE}/ReceiptPayment/SaveReceiptTransaction`;

   // Account API URL
   public static Customers_Api = `${Constants.API_BASE}/Account/Customers`;
   public static UnderGroup_Api =`${Constants.API_BASE}/Account/UnderGroup`;
   public static GetAllAccounts_Api = `${Constants.API_BASE}/Account/GetAll`;
   public static GetAccountDetail_Api =`${Constants.API_BASE}/Account/GetById`;
   public static DeleteAccount_Api =`${Constants.API_BASE}/Account/DeleteAccount`;
   public static AddAccount_Api = `${Constants.API_BASE}/Account/AddUpdateAccount`;
   public static DDLAccount_Api =   `${Constants.API_BASE}/Account/Accounts`


   // Journal Ledger
   public static GetAllJournalLedger_Api =`${Constants.API_BASE}/Ladger/GetAll`;

}
