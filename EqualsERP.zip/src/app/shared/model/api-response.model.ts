export class ApiResponse<T> {
  Message!: string;
  IsSuccess!: boolean;
  Data!: T;
  TotalRecord! :number
}
export class ServiceResponse<T> {
        IsSuccess!: boolean;
        Message!: string | null;
        StatusCode!: number;
        Data!: T | null;
        Exception!: string | null;
}
