export class ApiRequest {
}


export class IndexModel {
  Page!: number;
  PageSize!: number;
  Search!: string;
  OrderBy!: string;
  OrderByAsc!: boolean;
  IsPostBack!: boolean;
  AdvanceSearchModel?: { [key: string]: any; };
  constructor() {
    this.Page = 10;
    this.Page = 1;
    this.IsPostBack = false;
    this.AdvanceSearchModel = undefined;
  }
}
