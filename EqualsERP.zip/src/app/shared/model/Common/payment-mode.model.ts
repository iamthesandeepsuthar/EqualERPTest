
export class PaymentMode {
  Id!:number;
  Mode!:string;
}
export class PaymentType{
   Id!:number;
   Name!:string;
   ParentId!: number;
   CurrentBalance!:number;
}
export class Party {
  constructor() {
    this.CurrentBalance = 0;
  }
  Id!:number;
  Name!:number;
  Alias!:string;
  CurrentBalance:number;
  AccountId!:number;
}
export class Bills{
  Id!:number;
  BillNumber!:string;
  CustomerLedgerId!:number;
  Amount!:number;
}
