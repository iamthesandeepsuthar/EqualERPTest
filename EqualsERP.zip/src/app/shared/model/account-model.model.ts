
export class AccountModel {
  Id!: number;
  Name!: string | null;
  CustomerId!: number | null;
  CustomerName!: string | null;
  IsCustomer!: boolean;
  ParentId!: number | null;
  IsTCS!: boolean;
  IsGroup!: boolean;
  ParentName! :string;
  DefaultCreditPeriod!: number;
  MaintainByBalance!:boolean;
  CreditPeriod!: number;
  OpeningBalance!: number | null;
}
export class CustomerModel {
  Id!: number;
  Name!: string | null;
  Alias!: string | null;
}
export class DDLAccountModel {
  Id!: number;
  Name!: string;
}
export class UnderGroupModel {
  Id!: number;
  Name!: string | null;
  ParentId!: number | null;
  ParentName!: string;
}
