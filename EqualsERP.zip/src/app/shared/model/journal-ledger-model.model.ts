export class JournalLedgerModel {
  Date!: Date;
  OpeningBalance!: number;
  TransactionTypeId! : number;
  TransactionType!: string;
  VoucherNumber!: string;
  VoucherId!: number;
  DebitAmount!: number;
  CreditAmount!: number;
  Balance!: number;
  VoucherType!: string;
  IsDebit!: boolean;
  IsCredit!: boolean;
  AccountId!: number;
}
export class JournalLedgerRequestModel{
  FromDate!: Date;
  ToDate!: Date;
  AccountId!:number;
}
export  class FinalJournalLedgerModel {
  OpeningBalance!: number;
  Ledger!:JournalLedgerModel [];
}

