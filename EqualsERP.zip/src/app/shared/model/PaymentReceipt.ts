export class PaymentReceiveModel {
  constructor(){
    this.Ref_Bill = [];
  }
  Date!: Date;
  EntryTypeId!: number;
  DebitAccountId!: number;
  Amount!: number;
  PaymentModeId!: number;
  instrumentNo !: number | string;
  instrumentDate!: Date;
  PartyId!: number | string;
  Ref_Bill: ReferenceDetailViewModel[];
  Note!: string;

}
export class ReferenceDetailViewModel {
  RefId!:number;
  BillNo!: string;
  CustomerLedgerId!: number;
  RefAmount!: number;
  RefNotes!: string;
}


