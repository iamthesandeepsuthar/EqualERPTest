import { FormGroup } from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ledgers',
  templateUrl: './ledgers.component.html',
  styleUrls: ['./ledgers.component.css']
})
export class LedgersComponent implements OnInit {
  frmGroup!: FormGroup;
  constructor() { }

  ngOnInit(): void {
  }
  onSubmit() {

  }
}
