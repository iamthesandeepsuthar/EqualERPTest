
import { ReceiptComponent } from './receipt/receipt.component';
import { PaymentComponent } from './payment/payment.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AccountComponent } from './account/account.component';
import { JournalLedgerComponent } from './journal-ledger/journal-ledger.component';
import { LedgersComponent } from './ledgers/ledgers.component';
import { AccountsComponent } from './accounts/accounts.component';
import { ViewAccountComponent } from './view-account/view-account.component';

const routes: Routes = [
  {
    path: '',
    component: DashboardComponent,
  },
  {
    path: 'dashboard',
    component: DashboardComponent,
  },
  {
    path: 'account/:id',
    component: AccountComponent,
  },
  {
    path: 'accounts',
    component: AccountsComponent
  },
  {
    path: 'view-account/:id',
    component: ViewAccountComponent
  },
  {
    path:'payment',
    component:PaymentComponent
  },
  {
   path: 'receipt',
   component:ReceiptComponent
  },
  {
    path: 'journal-ledger',
    component:JournalLedgerComponent
  },
  {
    path:'ledger',
    component:LedgersComponent
  }
];

@NgModule({
  declarations: [],
  imports: [CommonModule, RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ERPRoutingModule {}
