import { FormBuilder, FormGroup } from '@angular/forms';
import { CommonService } from './../../shared/services/common.service';
import { Component, OnInit } from '@angular/core';
import { AccountModel } from 'src/app/shared/model/account-model.model';
import { AccountService } from 'src/app/shared/services/account.service';
import { AlertService } from 'src/app/shared/services/alert.service';
import { ActivatedRoute } from '@angular/router';
import { Constants } from 'src/app/shared/Constants';

@Component({
  selector: 'app-view-account',
  templateUrl: './view-account.component.html',
  styleUrls: ['./view-account.component.css']
})
export class ViewAccountComponent implements OnInit {
  readonly Constants = Constants;
  AccountForm!: FormGroup;
  private _accountModel : AccountModel;
  _id!:number;
  get AccountModel(): AccountModel{
    return this._accountModel;
  }
  constructor(private readonly fb: FormBuilder,private readonly _accountService: AccountService,
              private _alert: AlertService,
              private readonly _commonService: CommonService,
              private readonly _route: ActivatedRoute,) {
    this._accountModel = new AccountModel();
   }

  ngOnInit(): void {
    this.formInit();
    this._id = parseInt(this._commonService.GetParameter(this._route, 'id'));
    if(this._id>0) {
    this.GetAccountDetail(this._id);
    }
  }
   GetAccountDetail(id:number) {
    let subscription = this._accountService.GetAccountDetail(id).subscribe(res => {
      subscription.unsubscribe();
      if(res.IsSuccess) {
        this._accountModel = res.Data as AccountModel;
      }
    });
   }
   formInit() {
    this.AccountForm = this.fb.group({
      Name:[''],
      rbIsGroup:[''],
      customer: [''],
      rbIsCustomer: [true,],
      underGroup: [''],
      IsMaintainBalance:[],
      creditPeriod:[1],
      openingBalance:[0],
      IsTcs:['']
    });
  }
}
