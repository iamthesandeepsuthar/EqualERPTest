import { PaymentService } from './../../shared/services/payment.service';
import { PaymentReceiveModel } from './../../shared/model/PaymentReceipt';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ReferenceDetailViewModel } from 'src/app/shared/model/PaymentReceipt';
import { Bills, Party, PaymentMode, PaymentType } from 'src/app/shared/model/Common/payment-mode.model';
import { ToastrService } from 'ngx-toastr';
import { AlertService } from 'src/app/shared/services/alert.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  paymentForm!: FormGroup;
  private _paymentModel: PaymentReceiveModel = new PaymentReceiveModel();
  private _refItem!: ReferenceDetailViewModel;
  showRefItems!:boolean;
  IsBusy!: boolean;
  EntryType:number =24; // Payment
  private _paymentMode!:PaymentMode[];
  private _paymentType!:PaymentType[];
  private _party!:Party[];
  private _bills!: Bills[];
  private _totalAmount: number =0 ;
  private _currentBalance: number=0 ;
  IsUpdateRefItem:boolean = false;
  submitted = false;
  private currentDate: Date;

  constructor(private readonly fb: FormBuilder,
              private readonly _paymentService: PaymentService,
              private toastr: ToastrService,
              private _alert: AlertService
              ) {
   this._paymentModel = new PaymentReceiveModel();
   this._paymentModel.Amount = 0;
   this._refItem = new ReferenceDetailViewModel();
   this.showRefItems = false;
   this.IsBusy= false;
   this.currentDate = new Date();
  }
  // Public properties

  get f() { return this.paymentForm.controls; }
  get PaymentModel(): PaymentReceiveModel {
    return this._paymentModel;
  }
  get RefItem(): ReferenceDetailViewModel{
    return this._refItem;
  }
  get PaymentMode(): PaymentMode[]{
    return this._paymentMode;
  }
  get Bills(): Bills[] {
    return this._bills;
  }
  get Party():Party[] {
    return this._party;
  }
  get PaymentType(): PaymentType[] {
    return this._paymentType;
  }
  get TotalAmount(): number {
    return this._totalAmount;
  }
  set TotalAmount(value: number) {
    this._totalAmount = value;
  }
  get CurrentDate(): Date {
    return this.currentDate;
  }
  get CurrentBalance(): number {
    return this._currentBalance;
  }
  ngOnInit(): void {
    this.formInit();
    this.GetPaymentMode();
    this.GetPaymentType();
    this.GetParties();
  }
    // Bind Dropdown Data
  GetPaymentMode(){
    let subscription = this._paymentService.GetPaymentMode().subscribe(result => {
      subscription.unsubscribe();
      if(result.IsSuccess) {
        this._paymentMode = result.Data as PaymentMode[];
      } else {
       this._paymentMode = [];
      }
    });
  }
  GetPaymentType() {
    let subscription = this._paymentService.GetPaymentType().subscribe(result => {
    subscription.unsubscribe();
    if(result.IsSuccess){
      this._paymentType = result.Data as PaymentType[];
    } else {
      this._paymentType = [];
    }
    });
  }
  GetParties(){
    let subscription = this._paymentService.GetParty(this.EntryType).subscribe(result =>{
      subscription.unsubscribe();
      if(result.IsSuccess){
        this._party = result.Data as Party[];
      } else {
        this._party= [];
      }
    });
  }
  GetBills(partyId: any, EntryType: number) {
    this._bills = [];
  let subscription = this._paymentService.GetBills(partyId,EntryType).subscribe(result => {
    subscription.unsubscribe();
    if(result.IsSuccess){
    this._bills = result.Data as Bills[];
    } else {
      this._bills = [];
    }
  });
  }
  fillAmount(billId:number){
   const data = this._bills.find( x=>x.CustomerLedgerId == billId) as Bills;
   this._refItem.RefAmount = data.Amount;
   this._refItem.BillNo = data.BillNumber;
  }
  fillBalance(id: number) {
    this._currentBalance = 0;
   const data = this._party.find(x=>x.Id == id) as Party;
   this._currentBalance = data.CurrentBalance;
  }
  onAddItem(isUpdate: boolean){
    if(isUpdate) {
      const index  = this.PaymentModel.Ref_Bill.findIndex(x=>x.BillNo == this.RefItem.BillNo);
      this.PaymentModel.Ref_Bill[index].RefAmount = this.RefItem.RefAmount;
      this.PaymentModel.Ref_Bill[index].RefNotes = this.RefItem.RefNotes;
      this.PaymentModel.Ref_Bill[index].BillNo = this.RefItem.BillNo;
      this.PaymentModel.Ref_Bill[index].CustomerLedgerId = this.RefItem.CustomerLedgerId;
      this.IsUpdateRefItem = false;
      this._refItem = new ReferenceDetailViewModel();
      return;
      } else {
        if(this.RefItem.CustomerLedgerId == undefined) {
          this.showInfo('Please select bill number');
          return;}
        const isExist = this.PaymentModel.Ref_Bill.findIndex(x=>x.BillNo == this._refItem.BillNo );
        if(isExist<0) {
          this.PaymentModel.Ref_Bill.push(this.RefItem);
          this._totalAmount += this.RefItem.RefAmount;
          this.showRefItems= true;
          this._refItem = new ReferenceDetailViewModel();
          return;
        } else {
          this.showDuplicate(this._refItem.BillNo);
        }
      }
  }
  removeItem(index: number){
    this._alert.Question('Are you sure to delete record','Confirmation','Yes','No').then(isConfirm => {
      if(!isConfirm)
      return;
    const record = this.PaymentModel.Ref_Bill[index] as ReferenceDetailViewModel;
    this.TotalAmount -= record.RefAmount;
    this.PaymentModel.Ref_Bill.splice(index,1);
    if(this.PaymentModel.Ref_Bill.length<=0) {
      this.showRefItems =false;
    }
    });
  }
  getRefItem(index: number) {
     this._refItem= this.PaymentModel.Ref_Bill[index] as ReferenceDetailViewModel;
     this.IsUpdateRefItem = true;
  }
  onSubmit(){
   this.paymentForm.markAllAsTouched();
   this.submitted = true;
   if(this.TotalAmount !== this.PaymentModel.Amount) {
    this.showInfo('Ref bill amount not equal to total amount');
    return;
   }
   if(this.PaymentModel.Ref_Bill.length<1) {
    this.showInfo('Please add ref bill, before submission !');
    return;
   }
    if(this.paymentForm.valid){
    this.PaymentModel.EntryTypeId = this.EntryType;
    this._paymentService.SavePaymentTransaction(this.PaymentModel).subscribe(res => {
    if(res.IsSuccess) {
      this._alert.Success(res.Message!);
      this.resetForm();
       return;
      } else {
        let errorMsg = res.Message + '------' + res.Exception;
        this._alert.Error(errorMsg,'Error');
        return;
      }
    });
    }
  }
  resetForm() {
  this._paymentModel = new PaymentReceiveModel();
  this._refItem = new ReferenceDetailViewModel();
  this._paymentModel.Amount = 0;
  this.paymentForm.markAsUntouched();
  this.TotalAmount = 0;
  }
  formInit() {
    this.paymentForm = this.fb.group({
      Date: [undefined, Validators.compose([Validators.required])],
      Amount:[undefined,Validators.compose([Validators.required])],
      PaymentMode:[undefined,Validators.compose([Validators.required])],
      instrumentNo:['',],
      instrumentDate:[''],
      RefAmount:[''],
      PaymentTo:[undefined,Validators.compose([Validators.required])],
      Party:[''],
      refBill:[''],
      refNote:[''],
      Note:['']
    });
  }
  showSuccess(msg: string ) {
    this.toastr.success(msg,'Success !');
  }
  showWarning(){
   this.toastr.warning('Are you sure !','Warning');

  }
  showInfo(msg: string) {
    this.toastr.warning(msg,'Information');
  }
  showDuplicate(data: string){
    this.toastr.findDuplicate('Duplicate Record', data + ' already exist', false, true);
  }
}
