import { IndexModel } from './../../shared/model/Common/api-request.model';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Constants } from 'src/app/shared/Constants';
import { AccountModel } from 'src/app/shared/model/account-model.model';
import { AccountService } from 'src/app/shared/services/account.service';
import { AlertService } from 'src/app/shared/services/alert.service';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-accounts',
  templateUrl: './accounts.component.html',
  styleUrls: ['./accounts.component.css']
})
export class AccountsComponent implements OnInit {
  readonly Constants = Constants;
  private _accounts: AccountModel[];
  indexModel = new IndexModel();
  get Accounts(): AccountModel[] {
    return this._accounts;
  }

  dataSource: any;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  id!: number;
  displayedColumns: string[] = ['index', 'Name', 'ParentName', 'OpeningBalance', 'IsTCS', 'IsGroup', 'Action'];
  ViewdisplayedColumns = [{ Value: 'Name', Text: 'Name' }, { Value: 'ParentName', Text: 'Parent Group' },
   { Value: 'OpeningBalance', Text: 'Opening Balance' }];
  totalRecords: number = 0;

  constructor(private readonly _accountService: AccountService, private _alert: AlertService) {
    this._accounts = [];
  }

  ngOnInit(): void {
    this.GetAccountsList();
  }

  GetAccountsList() {
    let subscription = this._accountService.GetAllAccounts(this.indexModel).subscribe(res => {
      subscription.unsubscribe();
      if (res.IsSuccess) {
        this._accounts = res.Data.Data as AccountModel[];
        this.dataSource = new MatTableDataSource<AccountModel>(this._accounts);
        this.totalRecords = res.Data.TotalRecord as number;
        if (!this.indexModel.IsPostBack) {
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }
      } else {

        this._accounts = [];
      }
    });
  }

  DeleteAccount(Id: number) {
    this._alert.Question(`Are you sure you want to delete account`, 'Confirm Record Deletion').then(isConfirmed => {
      if (!isConfirmed)
        return;
      this._accountService.DeleteAccount(Id).subscribe(response => {
        if (response.IsSuccess) {
          this._alert.Success('Account deleted successfully');
          this.GetAccountsList();
        }
        else {
          this._alert.Error('An error occurred while deleting the account, please try again.');
        }
      });
    });
  }
  sortData(event: any): void {
    this.indexModel.OrderBy = event.active;
    this.indexModel.OrderByAsc = event.direction == "asc" ? true : false;
    this.indexModel.IsPostBack = true;
    this.GetAccountsList();
  }
  onSearch() {
    this.indexModel.Page = 1;
    this.indexModel.IsPostBack = false;

    this.GetAccountsList();
  }

  onPageSizeChange() {

    this.indexModel.IsPostBack = true;
    this.indexModel.PageSize = Number(this.indexModel.PageSize);
    this.GetAccountsList();
  }
  onPaginateChange(event: any) {
    this.indexModel.Page = event.pageIndex + 1;
    this.indexModel.PageSize = event.pageSize;
    this.indexModel.IsPostBack = true;
    this.GetAccountsList();
  }

}
