import { AccountService } from './../../shared/services/account.service';
import { ToastrService } from 'ngx-toastr';
import { JournalLedgerService } from './../../shared/services/journal-ledger.service';
import { FinalJournalLedgerModel} from './../../shared/model/journal-ledger-model.model';
import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { JournalLedgerRequestModel } from 'src/app/shared/model/journal-ledger-model.model';
import { DDLAccountModel } from 'src/app/shared/model/account-model.model';

@Component({
  selector: 'app-journal-ledger',
  templateUrl: './journal-ledger.component.html',
  styleUrls: ['./journal-ledger.component.css']
})
export class JournalLedgerComponent implements OnInit {
  frmGroup!: FormGroup;
  TotalDebit: number =0;
  TotalCredit: number =0;
  accounts!: DDLAccountModel[];
  request!: JournalLedgerRequestModel;
  model!: FinalJournalLedgerModel;
  get Request(): JournalLedgerRequestModel {
    return this.request;
  }
  get Account(): DDLAccountModel[] {
    return this.accounts;
  }
  set Request(model:JournalLedgerRequestModel) {
    this.request = model;
  }
  get Model(): FinalJournalLedgerModel {
    return this.model;
  }
  constructor(private readonly _ledgerService: JournalLedgerService,
              private readonly _toast : ToastrService,
              private readonly _accountService: AccountService) {
    this.request = new JournalLedgerRequestModel();
    this.model = new FinalJournalLedgerModel();
   }

  ngOnInit(): void {
    this.GetAccounts();
  }
  onSubmit() {
  }
  GetAccounts() {
    let subscription = this._accountService.GetAccounts().subscribe(x=>{
      subscription.unsubscribe();
      if(x.IsSuccess) {
       this.accounts= x.Data as DDLAccountModel [];
      } else {
      this._toast.info(x.Message?.toString(),'Record Not Found');
      }
      })
  }
  GetRecords(){
    let subscription = this._ledgerService.GetJournalLedgerList(this.request).subscribe(x=>{
    subscription.unsubscribe();
      if(x.IsSuccess) {
    this.model = x.Data as FinalJournalLedgerModel;
    if(this.model.Ledger.length>0) {
       this.calculateBalance();
       this.calculateTotalDebitCredit();
    }
   } else {
     this.model.Ledger = [];
   this._toast.info(x.Message?.toString(),'Record Not Found');
   }
   })
  }
  calculateBalance(): void {
   this.model.Ledger.forEach((x, index) => {
     if(index ==0) {
      x.Balance += this.model.OpeningBalance + x.DebitAmount - x.CreditAmount;
     } else {
      x.Balance += this.model.Ledger[index-1].Balance + x.DebitAmount - x.CreditAmount;
     }
   });
  }
  calculateTotalDebitCredit(): void {
    this.model.Ledger.forEach(x=> {
      if(x.IsDebit) {
        this.TotalDebit += x.DebitAmount;
      }
      if(x.IsCredit) {
        this.TotalCredit += x.CreditAmount;
      }
    })
   }
}
