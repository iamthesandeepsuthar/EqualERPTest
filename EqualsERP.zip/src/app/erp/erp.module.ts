import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ERPRoutingModule } from './erp-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AccountComponent } from './account/account.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { ReceiptComponent } from './receipt/receipt.component';
import { PaymentComponent } from './payment/payment.component';
import { JournalLedgerComponent } from './journal-ledger/journal-ledger.component';
import { LedgersComponent } from './ledgers/ledgers.component';
import { AccountsComponent } from './accounts/accounts.component';
import { ViewAccountComponent } from './view-account/view-account.component';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [
     DashboardComponent,
     AccountComponent,
     ReceiptComponent,
     PaymentComponent,
     JournalLedgerComponent,
     LedgersComponent,
     AccountsComponent,
     ViewAccountComponent,
  ],
  imports: [
    CommonModule,
    ERPRoutingModule,
    SharedModule
  ]
})
export class ERPModule { }
