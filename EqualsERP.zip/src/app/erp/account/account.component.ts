import { AccountModel, CustomerModel, UnderGroupModel } from './../../shared/model/account-model.model';
import { ToastrService } from 'ngx-toastr';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AccountService } from 'src/app/shared/services/account.service';
import { AlertService } from 'src/app/shared/services/alert.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Constants } from 'src/app/shared/Constants';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {
  readonly Constants = Constants;
  IsUpdate!:boolean;
   AccountForm!: FormGroup;
   AccountId!: number;
   model!: AccountModel;
   private _customers!:CustomerModel[];
   private _underGroup! : UnderGroupModel[];
   IsCustomer:boolean;
   IsBusy!: boolean;
   private _id!:number;
   get A () { return this.AccountForm.controls; }
   get AccountModel(): AccountModel {
    return this.model;
   }
  get Customers(): CustomerModel[] {
    return this._customers;
  }
  get Id(): number {
    return this._id;
  }
  get UnderGroups(): UnderGroupModel[] {
    return this._underGroup;
  }

   constructor(private readonly fb: FormBuilder,private readonly _router: Router,
    private readonly _accountService: AccountService,
    private toastr: ToastrService, private readonly _route: ActivatedRoute,
    private _alert: AlertService, private readonly _commonService: CommonService,) {
    this.IsBusy= false;
    this.IsUpdate = false;
    this.IsCustomer = true;
    this.model = new AccountModel();
    this.AccountModel.IsGroup = false;
    this.AccountModel.IsTCS = false;
    this.AccountModel.MaintainByBalance = false;
    this.AccountModel.IsCustomer = false;
 }
  ngOnInit(): void {
    this.formInit();
    this.GetCustomers();
    this.GetUnderGroup();
    this._id = parseInt(this._commonService.GetParameter(this._route, 'id'));
    if(this._id>0) {
      this.IsUpdate = true;
    this.GetAccountDetail(this._id);
    }
  }
  GetCustomers(){
    let subscription = this._accountService.GetCustomer().subscribe(res => {
      subscription.unsubscribe();
      if(res.IsSuccess) {
        this._customers = res.Data as CustomerModel[];
      } else {
       this._customers = [];
      }
    });
  }
  GetUnderGroup() {
    let subscription = this._accountService.GetUnderGroup().subscribe(res => {
    subscription.unsubscribe();
    if(res.IsSuccess){
      this._underGroup = res.Data as UnderGroupModel[];
    } else {
      this._underGroup = [];
    }
    });
  }
  GetAccountDetail(id:number) {
    let subscription = this._accountService.GetAccountDetail(id).subscribe(res => {
      subscription.unsubscribe();
      if(res.IsSuccess) {
        this.model = res.Data as AccountModel;
      }
    });
   }
  formInit() {
    this.AccountForm = this.fb.group({
      Name:[''],
      rbIsGroup:[''],
      customer: [''],
      rbIsCustomer: [true,],
      underGroup: [''],
      IsMaintainBalance:[''],
      creditPeriod:[1],
      openingBalance:[''],
      IsTcs:[false,]
    });
  }
  onSubmit(){
    if(!this.model.IsCustomer) {
    this.model.CustomerId =null;
    } else {
      this.model.Name = null;
    }
      this._accountService.SaveAccount(this.AccountModel).subscribe(res => {
        if(res.IsSuccess) {
          this._alert.Success(res.Message!).then(() => this._router.navigate([this.Constants.Account_List_URL]));;
          this.resetForm();
          } else {
          this._alert.Error(res.Exception! + " ---  " + res.Message,'Error');
          }
        });
  }
  resetForm() {
  this.AccountForm.reset();
  this.model = new AccountModel();
  this.AccountModel.IsGroup = false;
  this.AccountModel.IsTCS = false;
  this.AccountModel.MaintainByBalance = false;
  this.AccountModel.IsCustomer = false;
  }
}
