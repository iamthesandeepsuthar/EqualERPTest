import { PaymentReceiveModel } from './../../shared/model/PaymentReceipt';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ReferenceDetailViewModel } from 'src/app/shared/model/PaymentReceipt';
import { Bills, Party, PaymentMode, PaymentType } from 'src/app/shared/model/Common/payment-mode.model';
import { ReceiptService } from 'src/app/shared/services/receipt.service';
import { ToastrService } from 'ngx-toastr';
import { AlertService } from 'src/app/shared/services/alert.service';
import { ServiceResponse } from 'src/app/shared/model/api-response.model';

@Component({
  selector: 'app-receipt',
  templateUrl: './receipt.component.html',
  styleUrls: ['./receipt.component.css'],
})
export class ReceiptComponent implements OnInit {

  receiptForm!: FormGroup;
  private _receiptModel: PaymentReceiveModel = new PaymentReceiveModel();
  private _refItem!: ReferenceDetailViewModel;
  showRefItems!:boolean;
  IsBusy!: boolean;
  EntryType:number =23; // Receipt
  private _paymentMode!:PaymentMode[];
  private _paymentType!:PaymentType[];
  private _party!:Party[];
  private _bills!: Bills[];
  private _totalAmount: number =0 ;
  IsUpdateRefItem:boolean = false;
  submitted = false;
  private currentDate: Date;
  private _currentBalance : number ;


  constructor(private readonly fb: FormBuilder,
              private readonly _receiptService: ReceiptService,
              private toastr: ToastrService,
              private _alert: AlertService) {
   this._receiptModel = new PaymentReceiveModel();
   this._receiptModel.Amount = 0;
   this.currentDate = new Date();
   this._refItem = new ReferenceDetailViewModel();
   this.showRefItems = false;
   this.IsBusy= false;
   this._currentBalance = 0;
  }

  // Public properties
   // convenience getter for easy access to form fields
  get f() { return this.receiptForm.controls; }
  get ReceiptModel(): PaymentReceiveModel {
    return this._receiptModel;
  }
  get RefItem(): ReferenceDetailViewModel{
    return this._refItem;
  }
  get PaymentMode(): PaymentMode[]{
    return this._paymentMode;
  }
  get Bills(): Bills[] {
    return this._bills;
  }
  get Party():Party[] {
    return this._party;
  }
  get PaymentType(): PaymentType[] {
    return this._paymentType;
  }
  get TotalAmount(): number {
    return this._totalAmount;
  }
  set TotalAmount(value: number) {
    this._totalAmount = value;
  }
  get CurrentDate(): Date {
    return this.currentDate;
  }
  get CurrentBalance(): number {
    return this._currentBalance;
  }
  ngOnInit(): void {
    this.formInit();
    this.GetPaymentMode();
    this.GetPaymentType();
    this.GetParties();
  }
  // Bind Dropdown Data
  GetPaymentMode(){
    let subscription = this._receiptService.GetPaymentMode().subscribe(result => {
      subscription.unsubscribe();
      if(result.IsSuccess) {
        this._paymentMode = result.Data as PaymentMode[];
      } else {
       this._paymentMode = [];
      }
    });
  }
  GetPaymentType() {
    let subscription = this._receiptService.GetPaymentType().subscribe(result => {
    subscription.unsubscribe();
    if(result.IsSuccess){
      this._paymentType = result.Data as PaymentType[];
    } else {
      this._paymentType = [];
    }
    });
  }
  GetParties(){
    let subscription = this._receiptService.GetParty(this.EntryType).subscribe(result =>{
      subscription.unsubscribe();
      if(result.IsSuccess){
        this._party = result.Data as Party[];
      } else {
        this._party= [];
      }
    });
  }
  GetBills(partyId: any, EntryType: number) {
    this._bills = [];
    let subscription = this._receiptService.GetBills(partyId,EntryType).subscribe(result => {
    subscription.unsubscribe();
    if(result.IsSuccess){
    this._bills = result.Data as Bills[];
    //this._currentBalance = this._party.find(x=>x.Id== partyId)?.CurrentBalance;
    } else {
      this._bills = [];
    }
  });
  }
  fillAmount(billId:number){
   const data = this._bills.find( x=>x.Id == billId) as Bills;
   this._refItem.RefAmount = data.Amount;
   this._refItem.BillNo = data.BillNumber;
  }
  fillBalance(id: number) {
    this._currentBalance = 0;
   const data = this._party.find(x=>x.Id == id) as Party;
   //this._currentBalance = data.CurrentBalance;
  }
  onAddItem(isUpdate: boolean){
    if(isUpdate) {
    const index  = this.ReceiptModel.Ref_Bill.findIndex(x=>x.BillNo == this.RefItem.BillNo);
    this.ReceiptModel.Ref_Bill[index].RefAmount = this.RefItem.RefAmount;
    this.ReceiptModel.Ref_Bill[index].RefNotes = this.RefItem.RefNotes;
    this.ReceiptModel.Ref_Bill[index].BillNo = this.RefItem.BillNo;
    this.ReceiptModel.Ref_Bill[index].CustomerLedgerId = this.RefItem.CustomerLedgerId;
    this.IsUpdateRefItem = false;
    this._refItem = new ReferenceDetailViewModel();
      return;
    } else {
      if(this.RefItem.CustomerLedgerId == undefined) {
        this.showInfo('Please select bill number');
        return;
      }
      const isExist = this.ReceiptModel.Ref_Bill.findIndex(x=>x.BillNo == this._refItem.BillNo );
      if(isExist<0) {
        this.ReceiptModel.Ref_Bill.push(this.RefItem);
        this._totalAmount += this.RefItem.RefAmount;
        this.showRefItems= true;
        this._refItem = new ReferenceDetailViewModel();
        return;
      } else {
        this.showDuplicate(this._refItem.BillNo);
      }
    }
  }
  removeItem(index: number){
    this._alert.Question('Are you sure to delete record','Confirmation','Yes','No').then(isConfirm => {
      if(!isConfirm)
      return;
   const record = this.ReceiptModel.Ref_Bill[index] as ReferenceDetailViewModel;
   this.TotalAmount -= record.RefAmount;
   this.ReceiptModel.Ref_Bill.splice(index,1);
   if(this.ReceiptModel.Ref_Bill.length<=0) {
     this.showRefItems =false;   }
    });
  //  this.showWarning();
  }
  getRefItem(index: number) {
    this._refItem= this.ReceiptModel.Ref_Bill[index] as ReferenceDetailViewModel;
    this.IsUpdateRefItem = true;
  }

// Save Receipt Transaction
  onSubmit(): void{
   this.receiptForm.markAllAsTouched();
   this.submitted = true;
   if(this.TotalAmount !== this.ReceiptModel.Amount) {
    this.showInfo('Ref bill amount not equal to total amount');
    return;
   }
   if(this.ReceiptModel.Ref_Bill.length<1) {
    this.showInfo('Please add ref bill, before submission !');
    return;
   }
    if(this.receiptForm.valid){
    this.ReceiptModel.EntryTypeId = this.EntryType;
    this._receiptService.SaveReceiptTransaction(this.ReceiptModel).subscribe(res => {
    if(res.IsSuccess) {
      this._alert.Success(res.Message!);
      this.resetForm();
      } else {
      this._alert.Error(res.Exception! + " ---  " + res.Message,'Error');
      }
    });
    }
   }
  // Reset  Form Data
  resetForm() {
  this._receiptModel = new PaymentReceiveModel();
  this._refItem = new ReferenceDetailViewModel();
  this.TotalAmount = 0;
  this._receiptModel.Amount = 0;
  this.receiptForm.markAsUntouched();
  }
  // Form Initialization
  formInit() {
    this.receiptForm = this.fb.group({
      Date: [undefined, Validators.compose([Validators.required])],
      Amount:[undefined,Validators.compose([Validators.required])],
      PaymentMode:[undefined,Validators.compose([Validators.required])],
      instrumentNo:['',],
      instrumentDate:[''],
      RefAmount:[''],
      ReceiptAt:[undefined,Validators.compose([Validators.required])],
      Party:[''],
      refBill:[''],
      refNote:[''],
      Note:['']
    });
  }
  showSuccess(msg: string ) {
    this.toastr.success(msg,'Success !');
  }
  showWarning(){
   this.toastr.warning('Are you sure !','Warning');

  }
  showInfo(msg: string) {
    this.toastr.warning(msg,'Information');
  }
  showDuplicate(data: string){
    this.toastr.findDuplicate('Duplicate Record', data + ' already exist', false, true);
  }
}
