import { CommonService } from './../shared/services/common.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService } from '../shared/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  userId!: string;
  returnUrl!: string;
  constructor(
    private readonly _activateRoute: ActivatedRoute,
    private readonly _authService: AuthenticationService,
    private readonly _route: Router,
    private readonly _commonService: CommonService
  ) {
    if (
      _activateRoute.snapshot.params.returnUrl ||
      _activateRoute.snapshot.queryParamMap.get('returnUrl')
    ){
      this.returnUrl = _activateRoute.snapshot.params.returnUrl
      ? _activateRoute.snapshot.params.returnUrl
      : _activateRoute.snapshot.queryParamMap.get('returnUrl');
    }
    if (
      _activateRoute.snapshot.params.userId ||
      _activateRoute.snapshot.queryParamMap.get('userId')
    ) {
      this.userId = _activateRoute.snapshot.params.userId
        ? _activateRoute.snapshot.params.userId
        : _activateRoute.snapshot.queryParamMap.get('userId');
      this.AutoLogin();
    }

  }

  ngOnInit(): void {}
  AutoLogin() {

      this._authService.AutoLogin(this.userId).subscribe((res) => {
      if (res.IsSuccess) {
        debugger
        this._commonService.setStorage('authToken',res.Data as string)
        this._commonService.setStorage('sessionTime',String(new Date().setHours(24)));
        // Store Token And UserId
        this._authService.IsAuthentication.next(true);
        this._route.navigate(['erp']);
      } else {
       window.location.href = this.returnUrl;
      }
    });
  }
}
