import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../shared/services/auth.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
 
  constructor(private readonly _authService: AuthenticationService, private readonly _route: Router) {}

    ngOnInit() {

        }
    logOut() {
    this._authService.LogOut();
    this._route.navigate(['login']);
    }


  }
